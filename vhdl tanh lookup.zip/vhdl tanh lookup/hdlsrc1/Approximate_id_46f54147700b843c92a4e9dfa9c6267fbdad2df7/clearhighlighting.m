SLStudio.Utils.RemoveHighlighting(get_param('Approximate_id_46f54147700b843c92a4e9dfa9c6267fbdad2df7', 'handle'));
SLStudio.Utils.RemoveHighlighting(get_param('gm_Approximate_id_46f54147700b843c92a4e9dfa9c6267fbdad2df7', 'handle'));
annotate_port('gm_Approximate_id_46f54147700b843c92a4e9dfa9c6267fbdad2df7/Source', 0, 1, '');
annotate_port('gm_Approximate_id_46f54147700b843c92a4e9dfa9c6267fbdad2df7/Source/SigSpec1', 0, 1, '');
annotate_port('gm_Approximate_id_46f54147700b843c92a4e9dfa9c6267fbdad2df7/Source/DTC1', 0, 1, '');
annotate_port('gm_Approximate_id_46f54147700b843c92a4e9dfa9c6267fbdad2df7/Source/LUT', 0, 1, '');
